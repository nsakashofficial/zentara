import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { ProductCard } from "@/components/product-card";
import { getProduct, products } from "@/lib/products";

export const Route = createFileRoute("/product/$id")({
  loader: ({ params }) => {
    const product = getProduct(params.id);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.product.name} — ZENTARA` },
          { name: "description", content: loaderData.product.story },
          { property: "og:title", content: `${loaderData.product.name} — ZENTARA` },
          { property: "og:description", content: loaderData.product.story },
          { property: "og:image", content: loaderData.product.image },
        ]
      : [],
  }),
  notFoundComponent: () => (
    <div className="flex min-h-screen items-center justify-center bg-background text-foreground">
      <div className="text-center">
        <p className="text-[11px] uppercase tracking-[0.32em] text-gold">404</p>
        <h1 className="mt-4 font-display text-5xl">Piece not found.</h1>
        <Link
          to="/shop"
          className="mt-8 inline-block text-[11px] uppercase tracking-[0.22em] text-muted-foreground hover:text-gold"
        >
          Return to the atelier →
        </Link>
      </div>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="flex min-h-screen items-center justify-center bg-background p-8 text-center text-foreground">
      <div>
        <p className="text-[11px] uppercase tracking-[0.32em] text-gold">An error occurred</p>
        <p className="mt-4 font-display text-3xl">{error.message}</p>
      </div>
    </div>
  ),
  component: ProductPage,
});

function ProductPage() {
  const { product } = Route.useLoaderData();
  const [qty, setQty] = useState(1);
  const related = products.filter((p) => p.id !== product.id).slice(0, 4);

  return (
    <div className="relative min-h-screen bg-background text-foreground">
      <SiteHeader />

      <section className="mx-auto grid max-w-[1400px] gap-12 px-5 pb-24 pt-32 md:grid-cols-12 md:gap-16 md:px-10 md:pt-36">
        {/* Gallery */}
        <div className="md:col-span-7">
          <div className="relative aspect-[4/5] overflow-hidden bg-card animate-rise">
            <div className="absolute inset-0 opacity-70" style={{ background: "var(--gradient-radial-gold)" }} />
            <img
              src={product.image}
              alt={product.name}
              width={1024}
              height={1280}
              className="absolute inset-0 h-full w-full object-cover"
            />
            {product.edition && (
              <span className="absolute left-5 top-5 border hairline bg-background/50 px-3 py-1.5 text-[10px] uppercase tracking-[0.22em] text-gold backdrop-blur">
                {product.edition}
              </span>
            )}
          </div>
          <div className="mt-3 grid grid-cols-4 gap-3">
            {[1, 2, 3, 4].map((i) => (
              <button
                key={i}
                className={`aspect-square overflow-hidden bg-card transition ${i === 1 ? "ring-1 ring-gold" : "opacity-50 hover:opacity-100"}`}
              >
                <img src={product.image} alt="" loading="lazy" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="md:sticky md:top-32 md:col-span-5 md:self-start">
          <p className="text-[11px] uppercase tracking-[0.32em] text-gold">
            {product.collection} · {product.category}
          </p>
          <h1 className="mt-5 font-display text-5xl leading-[0.95] md:text-7xl">
            {product.name}
          </h1>
          <p className="mt-3 text-base text-muted-foreground">{product.tagline}</p>

          <div className="mt-8 flex items-baseline gap-4">
            <p className="font-display text-3xl text-gold">
              ${product.price.toLocaleString()}
            </p>
            <p className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
              {product.currency} · tax incl.
            </p>
          </div>

          <p className="mt-8 max-w-md text-base leading-relaxed text-muted-foreground">
            {product.story}
          </p>

          {/* Variants */}
          <div className="mt-10 space-y-6">
            <div>
              <p className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
                Finish
              </p>
              <div className="mt-3 flex gap-3">
                {["Brass", "Obsidian", "Ivory"].map((v, i) => (
                  <button
                    key={v}
                    className={`border hairline px-4 py-2 text-xs uppercase tracking-[0.18em] transition ${
                      i === 0 ? "border-gold text-gold" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
                Quantity
              </p>
              <div className="mt-3 inline-flex items-center border hairline">
                <button
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="px-4 py-2 text-muted-foreground hover:text-gold"
                >
                  −
                </button>
                <span className="w-10 text-center text-sm tabular-nums">{qty}</span>
                <button
                  onClick={() => setQty((q) => q + 1)}
                  className="px-4 py-2 text-muted-foreground hover:text-gold"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="mt-10 flex flex-col gap-3">
            <button className="group relative inline-flex items-center justify-between overflow-hidden bg-foreground px-7 py-5 text-[11px] uppercase tracking-[0.22em] text-background transition hover:shadow-glow">
              <span>Add to bag</span>
              <span>${(product.price * qty).toLocaleString()}</span>
            </button>
            <button className="border hairline px-7 py-5 text-[11px] uppercase tracking-[0.22em] text-muted-foreground transition hover:border-gold hover:text-gold">
              Save to wishlist
            </button>
          </div>

          {/* Details */}
          <div className="mt-12 border-t hairline">
            {([
              { label: "Details", content: product.details },
              { label: "Shipping & returns", content: ["Complimentary worldwide delivery", "30-day returns", "Carbon-neutral logistics"] },
              { label: "House promise", content: ["Lifetime maker's repair", "Authenticated provenance", "Members-first access"] },
            ] as { label: string; content: string[] }[]).map((sec, i) => (
              <details key={sec.label} className="group border-b hairline py-5" open={i === 0}>
                <summary className="flex cursor-pointer list-none items-center justify-between">
                  <span className="text-[11px] uppercase tracking-[0.22em] text-foreground">
                    {sec.label}
                  </span>
                  <span className="text-gold transition group-open:rotate-45">+</span>
                </summary>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  {sec.content.map((d) => (
                    <li key={d} className="flex gap-3"><span className="text-gold">·</span>{d}</li>
                  ))}
                </ul>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Related */}
      <section className="border-t hairline">
        <div className="mx-auto max-w-[1400px] px-5 py-24 md:px-10 md:py-32">
          <p className="text-[11px] uppercase tracking-[0.32em] text-gold">You may also keep</p>
          <h2 className="mt-5 font-display text-4xl leading-[0.95] md:text-6xl">
            Pieces in the same <span className="italic text-gradient-gold">register.</span>
          </h2>
          <div className="mt-16 grid gap-x-6 gap-y-16 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}