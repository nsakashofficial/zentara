import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { ProductCard } from "@/components/product-card";
import { products, collections, categories } from "@/lib/products";
import heroImg from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ZENTARA — A New Standard of Modern Luxury" },
      {
        name: "description",
        content:
          "A curated digital house for design objects, fragrance, fashion and sound. Pieces made to last a decade.",
      },
      { property: "og:title", content: "ZENTARA — A New Standard of Modern Luxury" },
      { property: "og:description", content: "A curated digital house. Made with intent." },
    ],
  }),
  component: Home,
});

const marqueeWords = [
  "Atelier 2026",
  "Worldwide Delivery",
  "Made With Intent",
  "Members First",
  "Hand Finished",
  "Edition of 240",
];

const testimonials = [
  {
    quote:
      "The kind of pieces you don't replace. ZENTARA understands the difference between expensive and considered.",
    author: "Marie Lavoie",
    role: "Editor, NOIR Magazine",
  },
  {
    quote:
      "Every detail — the box, the paper, the weight of the object — reads as intent. Rare.",
    author: "Idris Okafor",
    role: "Architect",
  },
  {
    quote:
      "I bought one fragrance and have since replaced half my apartment. Quietly addictive.",
    author: "Yuki Tanaka",
    role: "Collector",
  },
];

function Home() {
  const trending = products.slice(0, 4);
  const recommended = products.slice(4, 8);

  return (
    <div className="relative min-h-screen overflow-hidden bg-background text-foreground">
      <SiteHeader />

      {/* HERO */}
      <section className="relative flex min-h-[100svh] w-full items-end overflow-hidden pb-20 pt-32 md:items-center md:pb-0">
        <div className="absolute inset-0 -z-10">
          <img
            src={heroImg}
            alt="ZENTARA — Horizon 01"
            width={1600}
            height={1920}
            className="h-full w-full object-cover opacity-90"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/10 to-background" />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/30 to-transparent" />
        </div>

        <div className="relative mx-auto w-full max-w-[1400px] px-5 md:px-10">
          <div className="max-w-2xl animate-rise">
            <p className="text-[11px] uppercase tracking-[0.32em] text-gold">
              Atelier 2026 · Volume One
            </p>
            <h1 className="mt-6 font-display text-[15vw] leading-[0.88] tracking-tight md:text-[8vw] lg:text-[7rem]">
              Objects worth
              <br />
              <span className="italic shimmer-gold">keeping.</span>
            </h1>
            <p className="mt-8 max-w-md text-base leading-relaxed text-muted-foreground md:text-lg">
              A quiet house for design, fragrance, fashion and sound. Each piece made
              with intent, in small numbers, by the hands of people we know.
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-4">
              <Link
                to="/shop"
                className="group relative inline-flex items-center gap-3 overflow-hidden border hairline bg-foreground px-7 py-4 text-[11px] uppercase tracking-[0.22em] text-background transition-all hover:shadow-glow"
              >
                <span className="relative z-10">Discover the Atelier</span>
                <span className="relative z-10 transition-transform group-hover:translate-x-1">→</span>
              </Link>
              <Link
                to="/product/$id"
                params={{ id: "horizon-01" }}
                className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground transition hover:text-gold"
              >
                See Horizon 01 →
              </Link>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-0 right-0 z-10 flex items-end justify-between px-5 text-[10px] uppercase tracking-[0.22em] text-muted-foreground md:px-10">
          <span>N · 41.40°</span>
          <span className="hidden md:inline">Scroll to enter ↓</span>
          <span>E · 2.17°</span>
        </div>
      </section>

      {/* MARQUEE */}
      <section className="border-y hairline bg-background/40 py-5 backdrop-blur">
        <div className="flex overflow-hidden">
          <div className="flex shrink-0 animate-marquee items-center gap-12 whitespace-nowrap pr-12 font-display text-2xl md:text-3xl">
            {[...marqueeWords, ...marqueeWords].map((w, i) => (
              <span key={i} className="flex items-center gap-12">
                <span className={i % 2 === 0 ? "text-foreground" : "italic text-gold"}>{w}</span>
                <span className="text-gold">✦</span>
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* TRENDING */}
      <section className="mx-auto max-w-[1400px] px-5 py-24 md:px-10 md:py-32">
        <SectionHead
          eyebrow="01 · Trending now"
          title={<>The pieces moving<br /><span className="italic text-gradient-gold">this season.</span></>}
          link={{ label: "View all", to: "/shop" }}
        />
        <div className="mt-16 grid gap-x-6 gap-y-16 sm:grid-cols-2 lg:grid-cols-4">
          {trending.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
      </section>

      {/* CATEGORIES */}
      <section id="editorial" className="border-t hairline bg-card/40">
        <div className="mx-auto max-w-[1400px] px-5 py-24 md:px-10 md:py-32">
          <SectionHead
            eyebrow="02 · The house"
            title={<>Six worlds,<br /><span className="italic text-gradient-gold">one standard.</span></>}
          />
          <div className="mt-16 grid grid-cols-2 gap-px overflow-hidden border hairline md:grid-cols-3">
            {categories.map((c, i) => (
              <Link
                key={c.id}
                to="/shop"
                className="group relative flex aspect-square flex-col justify-between bg-background p-6 transition hover:bg-card md:p-10"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                  0{i + 1} · {c.count} pieces
                </span>
                <div>
                  <h3 className="font-display text-4xl md:text-5xl">{c.name}</h3>
                  <p className="mt-2 text-[11px] uppercase tracking-[0.22em] text-gold opacity-0 transition group-hover:opacity-100">
                    Enter →
                  </p>
                </div>
                <div className="pointer-events-none absolute inset-0 -z-10 opacity-0 transition group-hover:opacity-100" style={{ background: "var(--gradient-radial-gold)" }} />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED COLLECTION */}
      <section id="atelier" className="relative overflow-hidden py-24 md:py-40">
        <div className="mx-auto grid max-w-[1400px] gap-16 px-5 md:grid-cols-12 md:px-10">
          <div className="md:col-span-5 md:sticky md:top-32 md:self-start">
            <p className="text-[11px] uppercase tracking-[0.32em] text-gold">
              03 · Featured collection
            </p>
            <h2 className="mt-6 font-display text-6xl leading-[0.9] md:text-7xl lg:text-8xl">
              The Atelier
              <br />
              <span className="italic text-gradient-gold">Volume One.</span>
            </h2>
            <p className="mt-8 max-w-md text-base leading-relaxed text-muted-foreground">
              Twelve pieces, drawn from the workshop floor. Released in small numbers
              and never reproduced.
            </p>
            <div className="mt-10 space-y-px border-t hairline">
              {collections.map((c) => (
                <div key={c.id} className="flex items-baseline justify-between border-b hairline py-4">
                  <div>
                    <p className="font-display text-2xl">{c.name}</p>
                    <p className="text-sm text-muted-foreground">{c.line}</p>
                  </div>
                  <span className="text-[11px] uppercase tracking-[0.22em] text-gold">
                    {c.count} pieces
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div className="grid gap-6 md:col-span-7 md:grid-cols-2">
            {recommended.map((p, i) => (
              <div
                key={p.id}
                className={i % 2 === 1 ? "md:mt-24" : ""}
              >
                <ProductCard product={p} index={i} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MANIFESTO */}
      <section className="border-y hairline bg-card/40">
        <div className="mx-auto max-w-[1100px] px-5 py-24 text-center md:px-10 md:py-40">
          <p className="text-[11px] uppercase tracking-[0.32em] text-gold">04 · House note</p>
          <p className="mx-auto mt-10 font-display text-3xl leading-[1.15] md:text-5xl lg:text-6xl">
            We make things slowly, in small numbers, with people we trust. We do not
            chase the season. We answer to the hand, the eye and the years that
            follow. <span className="italic text-gradient-gold">That is the standard.</span>
          </p>
          <p className="mt-12 text-[11px] uppercase tracking-[0.32em] text-muted-foreground">
            — The Maison, Established 2024
          </p>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="mx-auto max-w-[1400px] px-5 py-24 md:px-10 md:py-32">
        <SectionHead
          eyebrow="05 · Said about us"
          title={<>Quiet words<br /><span className="italic text-gradient-gold">from quiet rooms.</span></>}
        />
        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <figure
              key={i}
              className="glass-panel flex flex-col gap-8 p-8 shadow-luxe md:p-10"
            >
              <span className="font-display text-5xl leading-none text-gold">"</span>
              <blockquote className="font-display text-xl leading-snug md:text-2xl">
                {t.quote}
              </blockquote>
              <figcaption className="mt-auto border-t hairline pt-5">
                <p className="text-sm">{t.author}</p>
                <p className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
                  {t.role}
                </p>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}

function SectionHead({
  eyebrow,
  title,
  link,
}: {
  eyebrow: string;
  title: React.ReactNode;
  link?: { label: string; to: string };
}) {
  return (
    <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
      <div>
        <p className="text-[11px] uppercase tracking-[0.32em] text-gold">{eyebrow}</p>
        <h2 className="mt-6 font-display text-5xl leading-[0.9] md:text-6xl lg:text-7xl">
          {title}
        </h2>
      </div>
      {link && (
        <Link
          to={link.to}
          className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground transition hover:text-gold"
        >
          {link.label} →
        </Link>
      )}
    </div>
  );
}
