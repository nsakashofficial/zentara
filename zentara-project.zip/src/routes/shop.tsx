import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { ProductCard } from "@/components/product-card";
import { products, categories } from "@/lib/products";

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title: "Shop — ZENTARA" },
      { name: "description", content: "Browse objects, fragrance, fashion, sound, eyewear and jewelry from the ZENTARA atelier." },
      { property: "og:title", content: "Shop — ZENTARA" },
      { property: "og:description", content: "The full atelier — pieces made with intent." },
    ],
  }),
  component: Shop,
});

function Shop() {
  const [active, setActive] = useState<string>("all");
  const filtered =
    active === "all"
      ? products
      : products.filter((p) => p.category.toLowerCase() === active);

  return (
    <div className="relative min-h-screen bg-background text-foreground">
      <SiteHeader />

      <section className="mx-auto max-w-[1400px] px-5 pb-12 pt-36 md:px-10 md:pt-44">
        <p className="text-[11px] uppercase tracking-[0.32em] text-gold">The Atelier</p>
        <h1 className="mt-6 font-display text-6xl leading-[0.9] md:text-8xl">
          The full
          <br />
          <span className="italic text-gradient-gold">collection.</span>
        </h1>
        <p className="mt-8 max-w-lg text-sm leading-relaxed text-muted-foreground md:text-base">
          {products.length} pieces, drawn from every world of the house. Sorted by the
          season's quiet preference.
        </p>
      </section>

      <section className="sticky top-[72px] z-30 border-y hairline glass-panel">
        <div className="mx-auto flex max-w-[1400px] gap-2 overflow-x-auto px-5 py-4 md:px-10">
          <Chip active={active === "all"} onClick={() => setActive("all")}>
            All · {products.length}
          </Chip>
          {categories.map((c) => (
            <Chip
              key={c.id}
              active={active === c.name.toLowerCase()}
              onClick={() => setActive(c.name.toLowerCase())}
            >
              {c.name}
            </Chip>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-5 py-16 md:px-10 md:py-24">
        <div className="grid gap-x-6 gap-y-16 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
        {filtered.length === 0 && (
          <p className="py-32 text-center text-muted-foreground">
            No pieces in this world yet. Come back soon.
          </p>
        )}
      </section>

      <SiteFooter />
    </div>
  );
}

function Chip({
  children,
  active,
  onClick,
}: {
  children: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`whitespace-nowrap border hairline px-4 py-2 text-[11px] uppercase tracking-[0.22em] transition ${
        active
          ? "border-transparent bg-foreground text-background"
          : "text-muted-foreground hover:text-gold"
      }`}
    >
      {children}
    </button>
  );
}