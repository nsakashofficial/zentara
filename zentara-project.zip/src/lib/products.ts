import watch from "@/assets/product-watch.jpg";
import fragrance from "@/assets/product-fragrance.jpg";
import bag from "@/assets/product-bag.jpg";
import audio from "@/assets/product-audio.jpg";
import knit from "@/assets/product-knit.jpg";
import vessel from "@/assets/product-vessel.jpg";
import eyewear from "@/assets/product-eyewear.jpg";
import jewelry from "@/assets/product-jewelry.jpg";

export type Product = {
  id: string;
  name: string;
  tagline: string;
  category: string;
  collection: string;
  price: number;
  currency: string;
  image: string;
  story: string;
  details: string[];
  edition?: string;
  badge?: string;
};

export const categories = [
  { id: "objects", name: "Objects", count: 24 },
  { id: "fragrance", name: "Fragrance", count: 12 },
  { id: "fashion", name: "Fashion", count: 38 },
  { id: "sound", name: "Sound", count: 9 },
  { id: "jewelry", name: "Jewelry", count: 17 },
  { id: "eyewear", name: "Eyewear", count: 14 },
];

export const products: Product[] = [
  {
    id: "horizon-01",
    name: "Horizon 01",
    tagline: "Automatic chronometer",
    category: "Objects",
    collection: "Atelier",
    price: 2480,
    currency: "USD",
    image: watch,
    edition: "Edition of 240",
    badge: "New",
    story:
      "A study in restraint. Brushed brass case, hand-finished movement, supple Tuscan leather. Built to outlast trend.",
    details: ["38mm brushed brass case", "Swiss automatic movement", "Sapphire crystal", "Aged Tuscan leather"],
  },
  {
    id: "noir-elixir",
    name: "Noir Élixir",
    tagline: "Extrait de Parfum 50ml",
    category: "Fragrance",
    collection: "Maison",
    price: 285,
    currency: "USD",
    image: fragrance,
    badge: "Signature",
    story:
      "Smoked oud, bitter orange and warm amber. Composed in Grasse over eighteen months. Worn close to the skin.",
    details: ["Top — bitter orange, pink pepper", "Heart — oud, leather, iris", "Base — amber, vanilla absolute", "Hand-blown vessel"],
  },
  {
    id: "tessera-tote",
    name: "Tessera",
    tagline: "Structured leather tote",
    category: "Fashion",
    collection: "Atelier",
    price: 1240,
    currency: "USD",
    image: bag,
    story:
      "Cut from a single hide of Italian saffiano. Architected, not assembled. A quiet object you'll carry for a decade.",
    details: ["Italian saffiano leather", "24k gold-plated hardware", "Suede interior", "Made in Florence"],
  },
  {
    id: "aura-headphones",
    name: "Aura",
    tagline: "Over-ear, lossless",
    category: "Sound",
    collection: "Studio",
    price: 690,
    currency: "USD",
    image: audio,
    badge: "New",
    story:
      "Tuned in Copenhagen, machined in Tokyo. 40-hour battery, lossless playback, leather you'll want to touch.",
    details: ["40mm beryllium drivers", "Active noise cancellation", "40h playback", "Hand-stitched leather"],
  },
  {
    id: "kashmir-knit",
    name: "Kashmir",
    tagline: "Grade A cashmere crewneck",
    category: "Fashion",
    collection: "Resort",
    price: 520,
    currency: "USD",
    image: knit,
    story:
      "Eight-ply cashmere from Inner Mongolia. Loomed in Biella. Designed to soften with every wear.",
    details: ["8-ply grade A cashmere", "Knit in Biella, Italy", "Ribbed cuffs and hem", "Heritage box packaging"],
  },
  {
    id: "ova-vessel",
    name: "Ova",
    tagline: "Sculpted bone china vessel",
    category: "Objects",
    collection: "Maison",
    price: 340,
    currency: "USD",
    image: vessel,
    edition: "Edition of 120",
    story:
      "Hand-thrown in Stoke, finished with a single arc of brushed gold. Each piece carries the maker's signature underneath.",
    details: ["Hand-thrown bone china", "Brushed gold detail", "Signed and numbered", "H 28cm × W 16cm"],
  },
  {
    id: "atlas-frames",
    name: "Atlas",
    tagline: "Italian acetate eyewear",
    category: "Eyewear",
    collection: "Atelier",
    price: 410,
    currency: "USD",
    image: eyewear,
    story:
      "Cut from Mazzucchelli acetate, polished by hand for nine days. Featherlight on the bridge, weight you don't notice.",
    details: ["Mazzucchelli M49 acetate", "Hand-polished, 9-day cycle", "Zeiss optical lenses", "Made in Cadore"],
  },
  {
    id: "lume-chain",
    name: "Lume",
    tagline: "18k recycled gold chain",
    category: "Jewelry",
    collection: "Maison",
    price: 1180,
    currency: "USD",
    image: jewelry,
    story:
      "A single drop of 18k recycled gold on a hand-linked chain. Quiet. Worn alone, or never taken off.",
    details: ["18k recycled gold", "Hand-linked chain, 42cm", "Lobster clasp", "Conflict-free, traceable"],
  },
];

export const collections = [
  {
    id: "atelier",
    name: "Atelier",
    line: "Pieces from the workshop floor.",
    count: 12,
  },
  {
    id: "maison",
    name: "Maison",
    line: "For the rooms you live in.",
    count: 18,
  },
  {
    id: "studio",
    name: "Studio",
    line: "Sound and image, refined.",
    count: 7,
  },
];

export const getProduct = (id: string) => products.find((p) => p.id === id);