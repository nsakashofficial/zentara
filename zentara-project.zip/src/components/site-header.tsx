import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";

const nav = [
  { to: "/shop", label: "Shop" },
  { to: "/shop", label: "Collections", search: { collection: "atelier" } },
  { to: "/shop", label: "Editorial" },
  { to: "/shop", label: "Atelier" },
];

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "glass-panel" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-[1400px] items-center justify-between px-5 py-4 md:px-10 md:py-5">
        <button
          aria-label="Menu"
          className="md:hidden"
          onClick={() => setMenuOpen((v) => !v)}
        >
          <span className="block h-px w-6 bg-foreground" />
          <span className="mt-1.5 block h-px w-4 bg-foreground" />
        </button>

        <nav className="hidden items-center gap-8 text-[11px] uppercase tracking-[0.22em] text-muted-foreground md:flex">
          <Link to="/shop" className="transition hover:text-foreground">Shop</Link>
          <Link to="/shop" className="transition hover:text-foreground">Collections</Link>
          <a href="#editorial" className="transition hover:text-foreground">Editorial</a>
          <a href="#atelier" className="transition hover:text-foreground">Atelier</a>
        </nav>

        <Link
          to="/"
          className="font-display text-2xl tracking-[0.42em] md:text-3xl"
          aria-label="ZENTARA"
        >
          <span className="text-gradient-gold">ZENTARA</span>
        </Link>

        <div className="flex items-center gap-5 text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
          <button className="hidden transition hover:text-foreground md:inline">Search</button>
          <button className="hidden transition hover:text-foreground md:inline">Account</button>
          <button className="relative transition hover:text-foreground">
            Bag <span className="text-gold">·0</span>
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="border-t hairline px-6 py-6 md:hidden">
          <ul className="flex flex-col gap-4 text-sm uppercase tracking-[0.22em] text-muted-foreground">
            {nav.map((n) => (
              <li key={n.label}>
                <Link to={n.to} onClick={() => setMenuOpen(false)}>
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </header>
  );
}