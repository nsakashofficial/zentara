import { Link } from "@tanstack/react-router";
import type { Product } from "@/lib/products";

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  return (
    <Link
      to="/product/$id"
      params={{ id: product.id }}
      className="group block animate-rise"
      style={{ animationDelay: `${index * 80}ms` }}
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-card">
        <div
          className="absolute inset-0 opacity-60"
          style={{ background: "var(--gradient-radial-gold)" }}
        />
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          width={1024}
          height={1280}
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-[1.04]"
        />
        {product.badge && (
          <span className="absolute left-4 top-4 z-10 border hairline bg-background/40 px-2.5 py-1 text-[10px] uppercase tracking-[0.22em] text-gold backdrop-blur">
            {product.badge}
          </span>
        )}
        <div className="absolute inset-x-0 bottom-0 z-10 translate-y-full bg-background/70 px-5 py-4 backdrop-blur transition-transform duration-500 group-hover:translate-y-0">
          <p className="text-[11px] uppercase tracking-[0.22em] text-gold">View piece →</p>
        </div>
      </div>
      <div className="mt-5 flex items-start justify-between gap-4">
        <div>
          <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
            {product.collection} · {product.category}
          </p>
          <h3 className="mt-1.5 font-display text-xl">{product.name}</h3>
          <p className="mt-0.5 text-sm text-muted-foreground">{product.tagline}</p>
        </div>
        <p className="whitespace-nowrap text-sm tabular-nums text-foreground/90">
          ${product.price.toLocaleString()}
        </p>
      </div>
    </Link>
  );
}