import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="relative mt-32 border-t hairline">
      <div className="mx-auto max-w-[1400px] px-5 py-20 md:px-10">
        <div className="grid gap-16 md:grid-cols-12">
          <div className="md:col-span-5">
            <h2 className="font-display text-5xl leading-[0.95] md:text-7xl">
              A new standard,
              <br />
              <span className="italic text-gradient-gold">quietly kept.</span>
            </h2>
            <p className="mt-8 max-w-md text-sm leading-relaxed text-muted-foreground">
              Receive our monthly dispatch. New objects, atelier notes, and pieces released
              to members first. No noise.
            </p>
            <form className="mt-8 flex max-w-md items-center border-b hairline pb-3">
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 bg-transparent text-sm placeholder:text-muted-foreground/60 focus:outline-none"
              />
              <button className="text-[11px] uppercase tracking-[0.22em] text-gold transition hover:text-accent">
                Subscribe →
              </button>
            </form>
          </div>

          <div className="grid grid-cols-2 gap-10 md:col-span-7 md:grid-cols-4">
            <FooterCol
              title="House"
              links={["Atelier", "Editorial", "Sustainability", "Press"]}
            />
            <FooterCol
              title="Shop"
              links={["Objects", "Fragrance", "Fashion", "Sound"]}
            />
            <FooterCol
              title="Service"
              links={["Contact", "Concierge", "Shipping", "Returns"]}
            />
            <FooterCol
              title="Legal"
              links={["Privacy", "Terms", "Cookies", "Imprint"]}
            />
          </div>
        </div>

        <div className="mt-20 flex flex-col items-start justify-between gap-6 border-t hairline pt-8 text-[11px] uppercase tracking-[0.22em] text-muted-foreground md:flex-row md:items-center">
          <Link to="/" className="font-display text-lg tracking-[0.42em] text-gradient-gold">
            ZENTARA
          </Link>
          <p>© {new Date().getFullYear()} ZENTARA Maison. Made with care.</p>
          <div className="flex gap-5">
            <span>EN</span>
            <span className="text-gold">·</span>
            <span>USD</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: string[] }) {
  return (
    <div>
      <h4 className="mb-4 text-[11px] uppercase tracking-[0.22em] text-gold">{title}</h4>
      <ul className="space-y-3 text-sm text-muted-foreground">
        {links.map((l) => (
          <li key={l}>
            <a href="#" className="transition hover:text-foreground">
              {l}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}